public class TesterClass
{ 
	public static void main(String[] args)
   { 
   	   BankAccount.setMaxFreeTransactions(3);
   	   System.out.println("Current fee is: " + BankAccount.getFee());
   	   BankAccount.setFee(5);   	   
   	   System.out.println("New current fee is: " + BankAccount.getFee());
   	   BankAccount account = new BankAccount(200);
   	   for(int i = 0; i < 5; i++)
   	   {
   	   	   account.deposit(50);
   	   	   account.withdraw(60);
   	   }
   	   System.out.println("New Month, charge fees...");   	  
   	   account.deductMonthlyCharge();
   	   System.out.println("");
   	    
   	   for(int i = 0; i < 5; i++)
   	   {
   	   	   account.deposit(50);
   	   	   account.withdraw(60);
   	   }
   	   System.out.println("New Month, charge fees...");
   	   account.deductMonthlyCharge();
   }
  
}